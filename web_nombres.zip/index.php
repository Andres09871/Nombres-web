<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css" integrity="sha384-/Y6pD6FV/Vv2HJnA6t+vslU6fwYXjCFtcEpHbNJ0lyAFsXTsjBbfaDjzALeQsN6M" crossorigin="anonymous">
  <title>Prueba</title>
 
</head>

<body>

<header id="main-header" class="bg-info text-white p-4 mb-3">
    <div class="container">
    

 

  
    
    <output type="text" name="txtNombre"> <br />
   


    <header id="main-header" class="bg-info text-white p-4 mb-3">
    <div class="container">
      <h1 id="header-title">Lista </h1>
      <br/>
    </div>
  </header>
  <div class="container">
   <div id="main" class="card card-body">

    <h2 class="title"> ____________________</h2>
    <?php

      echo 'table border="1">';
      echo 'tr>';
      echo 'th Nombre';
      echo '</tr';

  echo '<td>','Camilo Andres Rodriguez Martinez', '</td>';
  echo '<table>'
    ?>
  
   
    <select name="cmbSexo"> 
    
      <option value="Masculino">Camilo Andres Rodriguez Martinez</option>
      <option value="Femenino">F</option>
    </select> <br/>
  </form>
</body>

</html>